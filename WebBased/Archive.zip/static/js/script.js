$(document).ready(function(){
  $(upload_file_btn).on('click', function(){
    upload_file.click();
  });
  $(upload_file).on('change', function(){
    if(upload_file.files.length===0)
      return $(upload_file_name).removeClass('d-none').addClass('d-none').text('');
    return $(upload_file_name).removeClass('d-none').text(upload_file.files[0].name);
  });
  $(compare_btn).on('click', function(){
    if($(this).text()!=='Compare')
      return;
    if(upload_file.files.length===0)
      return $(upload_error).removeClass('d-none').text('Please upload a file');
    performAction(upload_file.files[0]);
  });
  $(again_btn).on('click', function(){
    $(report_block).removeClass('d-none').addClass('d-none');
    $(upload_block).removeClass('d-none');
  })
});

function performAction(file){
  $(upload_error).removeClass('d-none').addClass('d-none');
  $(compare_btn).html(`<i class="fa fa-refresh fa-pulse mr-2"></i> Comparing...`);
  let formData = new FormData();
  formData.append('document', file);
  $.ajax({
    url: '/pagiarism',
    type: "POST",
    data: formData,
    success: function (data) {
      if(data.status) {
        $(upload_file).val('');
        $(upload_file_name).removeClass('d-none').addClass('d-none');
        $(upload_block).removeClass('d-none').addClass('d-none');
        $(report_block).removeClass('d-none');
        setData(data.response);
      }
      else {
        $(upload_error).removeClass('d-none').text('Something went wrong');
      }
      $(compare_btn).text('Compare');
    },
    cache: false,
    contentType: false,
    processData: false,
    error:function(err){
      $(upload_error).removeClass('d-none').text('Something went wrong');
      $(compare_btn).text('Compare');
    }
  });
}

function setColor(percentange) {
  if(percentange<50)
    return "success";
  else if(percentange<75)
    return "warning";
  else
    return "danger";
}

function setData(data) {
  $(report_block).find('tbody').empty();
  data.forEach( (record) => {
    let filename = record[0];
    let percentange = Math.ceil(record[1]*100);
    $(report_block).find('tbody').append(`
      <tr>
        <td class="p-1"><a class="btn btn-link" href="/document/${filename}" target="document_frame" onclick="$('.modal').modal('show')">${filename}</a></td>
        <td class="p-1">
          <div class="w-100" style="background-color: #dee0e2;">
            <div class="text-center bg-${setColor(percentange)} text-white px-1" style="width:${percentange}%;">${percentange}%</div>
          </div>
        </td>
      </tr>
    `);
  })
}